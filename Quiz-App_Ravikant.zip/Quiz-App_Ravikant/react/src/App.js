import React, { Component } from 'react';
import LogIn from './Components/LogIn.jsx';
import  './App.css';

class App extends Component {
    render() {
        return (
                <LogIn />
        );
    }
}

export default App;