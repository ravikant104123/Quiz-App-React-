-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 15, 2019 at 02:44 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Quiz-App`
--

-- --------------------------------------------------------

--
-- Table structure for table `Questions_set`
--

CREATE TABLE `Questions_set` (
  `id` int(11) NOT NULL,
  `topic_name` varchar(30) NOT NULL,
  `question_title` tinytext NOT NULL,
  `question_description` text NOT NULL,
  `options` tinytext NOT NULL,
  `answer` tinytext,
  `status` enum('Enabled','Disabled') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Questions_set`
--

INSERT INTO `Questions_set` (`id`, `topic_name`, `question_title`, `question_description`, `options`, `answer`, `status`) VALUES
(1, 'PHP', 'Basic Question', 'Which of the following type of variables are sequences of characters, like \'PHP supports string operations.\'?', 'Strings,Arrays,Objects,Resources', 'Strings', 'Enabled'),
(2, 'PHP', 'Basic Question', ' Which of the following magic constant of PHP returns function name?', '_LINE_,_FILE_,_FUNCTION_,_CLASS_', '_FUNCTION_', 'Enabled'),
(3, 'PHP', 'Basic Question', 'Which of the following array represents an array containing one or more arrays?', 'Numeric Array,Associative Array,Multidimentional Array,None of the above.', 'Multidimentional Array', 'Enabled'),
(4, 'PHP', 'Basic Question', 'Which of the following can be used to get information sent via get/post method in PHP?', '$_REQUEST,$REQUEST,$REQUEST_PAGE,None of the above.', '$_REQUEST', 'Enabled'),
(5, 'PHP', 'Basic Question', 'Which of the following is used to access session variables in PHP?', 'session_start() function,$_SESSION[],isset() function,session_destroy() function', '$_SESSION[]', 'Enabled'),
(6, 'PHP', 'Advance Question', 'Which of the following method of Exception class returns formated string of trace?', 'getMessage(),getCode(),getTrace(),getTraceAsString()', 'getTraceAsString()', 'Enabled'),
(7, 'PHP', 'Advance Question', 'Which of the following method acts as a destructor function in a PHP class?', 'class_name(), __destruct,destructor,None of the above.', '__destruct', 'Enabled'),
(8, 'PHP', 'Basic Question', 'What does PHP stand for ?', 'Pretext Hypertext Processor,Hypertext Preprocessor,Preprocessor Home Page,None of the above', 'Hypertext Preprocessor', 'Enabled'),
(9, 'PHP', 'Basic Question', 'Who is the father of PHP ?', 'Drek Kolkevi,List Barely,Willam Makepiece,Rasmus Lerdorf', 'Rasmus Lerdorf', 'Enabled'),
(10, 'PHP', 'Basic Question', 'PHP files have a default file extension of', '.phpf,.ph,.p,.php', '.php', 'Enabled'),
(11, 'JAVASCRIPT', 'Basic Question', 'What is the HTML tag under which one can write the JavaScript code?', '<javascript>,<scripted>,<script>,<js>', '<script>', 'Enabled'),
(12, 'JAVASCRIPT', 'Basic Question', 'What is the correct syntax for referring to an external script called “geek.js”?', '<script src=”geek.js”>,<script href=”geek.js”>,<script ref=”geek.js”>,<script name=”geek.js”>', '<script src=”geek.js”>', 'Enabled'),
(13, 'JAVASCRIPT', 'Basic Question', 'The external JavaScript file must contain <script> tag. True or False? ', 'True,False', 'False', 'Enabled'),
(14, 'JAVASCRIPT', 'Basic Question', 'Which of the following is not a reserved word in JavaScript?', 'interface,throws,program,short', 'program', 'Enabled'),
(15, 'JAVASCRIPT', 'Basic Question', 'What is the syntax for creating a function in JavaScript named as Geekfunc?', 'function = Geekfunc(),function Geekfunc(),function := Geekfunc(),function : Geekfunc()', 'function Geekfunc()', 'Enabled'),
(16, 'JAVASCRIPT', 'Basic Question', 'How is the function called in JavaScript?', 'call Geekfunc();,call function GeekFunc();,Geekfunc();,function Geekfunc();', 'Geekfunc();', 'Enabled'),
(17, 'JAVASCRIPT', 'Basic Question', 'How to write an ‘if’ statement for executing some code:  If “i” is NOT equal to 8?', 'if(i<>5),if i<>5,if(i!=5),if i!=5', 'if(i!=5)', 'Enabled'),
(18, 'JAVASCRIPT', 'Basic Question', 'What is the correct syntax for adding comments in JavaScript?', '<!–This is a comment-->,//This is a comment,–This is a comment,**This is a comment**', '//This is a comment', 'Enabled'),
(19, 'JAVASCRIPT', 'Basic Question', 'What is the JavaScript syntax for printing values in Console?', 'print(5),console.log(5);,console.print(5);,print.console(5);', 'console.log(5);', 'Enabled'),
(20, 'JAVASCRIPT', 'Basic Question', 'What is the method in JavaScript used to remove the whitespace at the beginning and end of any string ?', 'strip(),trim(),stripped(),trimmed()', 'trim()', 'Enabled'),
(21, 'REACT', 'Basic Question', 'How do you access a function fetch() from a h1 element in JSX?', '<h1>{fetch()}</h1>,<h1>${fetch()}</h1>,<h1>{fetch}</h1>,<h1>${fetch}</h1>', '<h1>{fetch()}</h1>', 'Enabled'),
(22, 'REACT', 'Basic Question', 'Which method in a React Component should you override to stop the component from updating?', 'willComponentUpdate,shouldComponentUpdate,componentDidUpdate,componentDidMount', 'shouldComponentUpdate', 'Enabled'),
(23, 'REACT', 'Basic Question', 'What\'s used to pass data to a component from outside?', 'setState,render with arguments,PropTypes,props', 'props', 'Enabled'),
(24, 'REACT', 'Basic Question', 'Which method in a React Component is called after the component is rendered for the first time?', 'componentDidUpdate,componentDidMount,componentMounted,componentUpdated', 'componentDidMount', 'Enabled'),
(25, 'REACT', 'Basic Question', 'Which of the following is correct syntax for a button click event handler, foo?', '<button onclick={this.foo()}>,<button onclick={this.foo}>,<button onClick={this.foo()}>,<button onClick={this.foo}>', '<button onClick={this.foo}>', 'Enabled'),
(26, 'REACT', 'Basic Question', 'What happens when you call setState() inside render() method?', 'Repetitive output appears on the screen,Stack overflow error,Duplicate key error,Nothing happens. Life goes on!', 'Stack overflow error', 'Enabled'),
(27, 'REACT', 'Basic Question', 'How do you write an inline style specifying the font-size:12px and color:red; in JSX', 'style={{font-size:12,color:\'red\'}},style={{fontSize:\'12px\',color:\'red\'}},style={fontSize:\'12px\',color:\'red\'},style={{font-size:12px,color:\'red\'}}', 'style={{fontSize:\'12px\',color:\'red\'}}', 'Enabled'),
(28, 'REACT', 'Basic Question', 'Everything in React is a _____________', 'Module,Component,Package,Class', 'Component', 'Enabled'),
(29, 'REACT', 'Basic Question', 'In which directory React Components are saved?', 'Inside js/components/,Inside vendor/components/,Inside external/components/,Inside vendor/', 'Inside js/components/', 'Enabled'),
(30, 'REACT', 'Basic Question', 'What is Babel?', 'A transpiler,An interpreter,A Compiler,Both Compiler and Transpilar', 'Both Compiler and Transpilar', 'Enabled'),
(31, 'MYSQL', 'Basic Question', 'Which SQL statement is used to insert a new data in a database ?', 'INSERT NEW,ADD,UPDATE,INSERT INTO', 'INSERT INTO', 'Enabled'),
(32, 'MYSQL', 'Basic Question', 'Which program converts binary log files to statements in text form?', 'mysqldump,mysqllog,mysqlbin,mysqlbinlog', 'mysqlbinlog', 'Enabled'),
(33, 'MYSQL', 'Basic Question', 'What does SQL stand for?', 'Structured Query Language,Structured Question Language,Strong Question Language,', 'Structured Query Language', 'Enabled'),
(34, 'MYSQL', 'Basic Question', 'Which SQL statement is used to extract data from a database?', 'SELECT,GET,EXTRACT,OPEN', 'SELECT', 'Enabled'),
(35, 'MYSQL', 'Basic Question', 'Which SQL statement is used to update data in a database?', 'UPDATE,SAVE AS,MODIFY,SAVE', 'UPDATE', 'Enabled'),
(36, 'MYSQL', 'Basic Question', 'Which SQL statement is used to delete data from a database?', 'DELETE,REMOVE,COLLAPSE,', 'DELETE', 'Enabled'),
(37, 'MYSQL', 'Basic Question', 'Which operator is used to select values within a range?', 'RANGE,WITHIN,BETWEEN,', 'BETWEEN', 'Enabled'),
(38, 'MYSQL', 'Basic Question', 'What is the most common type of join?', 'INNER JOIN,JOINED,INSIDE JOIN,JOINED TABLE', 'INNER JOIN', 'Enabled'),
(39, 'MYSQL', 'Basic Question', 'With SQL, how can you return all the records from a table named \"Persons\" sorted descending by \"FirstName\"?', 'SELECT * FROM Persons ORDER BY FirstName DESC,SELECT * FROM Persons ORDER FirstName DESC,SELECT * FROM Persons SORT BY \'FirstName\' DESC,SELECT * FROM Persons SORT \'FirstName\' DESC', 'SELECT * FROM Persons ORDER BY FirstName DESC', 'Enabled'),
(40, 'MYSQL', 'Basic Question', 'Which SQL statement is used to return only different values?', 'SELECT DISTINCT,SELECT DIFFERENT,SELECT UNIQUE,', 'SELECT DISTINCT', 'Enabled'),
(41, 'POLITICS', 'Basic Question', 'The members of the Rajya Sabha are elected by', 'the people,Lok Sabha,elected members of the legislative assembly,elected members of the legislative council', 'elected members of the legislative assembly', 'Enabled'),
(42, 'POLITICS', 'Basic Question', 'The power to decide an election petition is vested in the', 'Parliament,Supreme Court,High courts,Election Commission', 'High courts', 'Enabled'),
(43, 'POLITICS', 'Basic Question', 'The present Lok Sabha is the', '13th Lok Sabha,14th Lok Sabha,15th Lok Sabha,16th Lok Sabha', '16th Lok Sabha', 'Enabled'),
(44, 'POLITICS', 'Basic Question', 'The members of Lok Sabha hold office for a term of', '4 years,5 years,6 years,3 years', '5 years', 'Enabled'),
(45, 'POLITICS', 'Basic Question', 'The minimum age to qualify for election to the Lok Sabha is', '25 years,21 years,18 years,35 years', '25 years', 'Enabled'),
(46, 'POLITICS', 'Basic Question', 'The minimum age of the voter in India is', '15 years,18 years,21 years,25 years', '18 years', 'Enabled'),
(47, 'POLITICS', 'Basic Question', 'The president can dissolve the Lok Sabha on', 'advice of the prime minister,advice of the chief justice of India,recommendation of Lok Sabha,recommendation of the Rajya Sabha', 'advice of the prime minister', 'Enabled'),
(48, 'POLITICS', 'Basic Question', 'The office of the president can fall vacant due to', 'resignation,death,removal,All of the above', 'All of the above', 'Enabled'),
(49, 'POLITICS', 'Basic Question', 'The office of the prime minister of India', 'has a constitutional basis,has a statutory basis,has conventional basis,None of the above', 'has a constitutional basis', 'Enabled'),
(50, 'POLITICS', 'Basic Question', 'The power to prorogue the Lok Sabha rests with', 'the speaker,the president,the prime minister,the minister for parliamentary affairs', 'the president', 'Enabled'),
(51, 'GRAMMAR', 'Basic Question', 'The first letter of the first word in a sentence should be', 'a large letter,a capital letter', 'a capital letter', 'Enabled'),
(52, 'GRAMMAR', 'Basic Question', 'The order of a basic positive sentence is', 'Subject-Verb-Object,Verb-Object-Subject', 'Subject-Verb-Object', 'Enabled'),
(53, 'GRAMMAR', 'Basic Question', 'Every sentence must have a subject and', 'a verb,an object', 'a verb', 'Enabled'),
(54, 'GRAMMAR', 'Basic Question', 'A plural subject needs', 'a singular verb,a plural verb', 'a plural verb', 'Enabled'),
(55, 'GRAMMAR', 'Basic Question', 'Adjectives usually come', 'before a noun,after a noun', 'before a noun', 'Enabled'),
(56, 'GRAMMAR', 'Basic Question', 'When two singular subjects are connected by or, use', 'a singular verb,a plural verb', 'a singular verb', 'Enabled'),
(57, 'GRAMMAR', 'Basic Question', 'If an opinion-adjective and a fact-adjective are used before a noun, which comes first?', 'a fact-adjective,an opinion-adjective', 'an opinion-adjective', 'Enabled'),
(58, 'GRAMMAR', 'Basic Question', 'In British English, a collective noun is usually treated as', 'singular,plural', 'plural', 'Enabled'),
(59, 'GRAMMAR', 'Basic Question', 'The terms \"its\" and \"it\'s\" have', 'he same meaning,different meanings', 'different meanings', 'Enabled'),
(60, 'GRAMMAR', 'Basic Question', 'Which is correct?', 'You\'re looking good,Your looking good', 'You\'re looking good', 'Enabled'),
(61, 'HISTORY', 'Basic Question', 'Falkland Islands, located in South Atlantic Ocean, are a self-governing Overseas Territory of which country ?', 'Spain,United Kingdom,Germany,France', 'United Kingdom', 'Enabled'),
(62, 'HISTORY', 'Basic QUestion', 'Gautam Buddha as a prince was known as:', 'Gautam,Siddhartha,Rahul,Suddhodhana', 'Siddhartha', 'Enabled'),
(63, 'HISTORY', 'Basic Question', 'The deep transforming effect that the Kalinga War had on Ashoka has been described in:', 'Archaeological excavations,Rock edicts,Coins,Pillar edicts', 'Rock edicts', 'Enabled'),
(64, 'HISTORY', 'Basic Question', 'The largest masjid in India, Jama Masjid, was built by which Mughal emperor?', 'Aurangzeb,Shahjahan,Akbar,Jahangir', 'Shahjahan', 'Enabled'),
(65, 'HISTORY', 'Basic Question', 'The mother of Vardhamana Mahavira was a:', 'Lichavi Princess,Maurya Princess,Saka Princess,Not a member of the royal family', 'Lichavi Princess', 'Enabled');

-- --------------------------------------------------------

--
-- Table structure for table `Quiz_categories`
--

CREATE TABLE `Quiz_categories` (
  `id` int(11) NOT NULL,
  `categories` varchar(20) NOT NULL,
  `soft_delete` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Quiz_categories`
--

INSERT INTO `Quiz_categories` (`id`, `categories`, `soft_delete`) VALUES
(1, 'PROGRAMMING LANGUAGE', 0),
(2, 'DATABASE', 0),
(3, 'G & K', 0),
(4, 'ENGLISH', 0),
(5, 'SOCIAL SCIENCE', 0),
(6, 'SCIENCE', 0);

-- --------------------------------------------------------

--
-- Table structure for table `Quiz_topics`
--

CREATE TABLE `Quiz_topics` (
  `id` int(11) NOT NULL,
  `category_name` varchar(20) NOT NULL,
  `topic_name` varchar(30) NOT NULL,
  `topic_description` text NOT NULL,
  `soft_delete` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Quiz_topics`
--

INSERT INTO `Quiz_topics` (`id`, `category_name`, `topic_name`, `topic_description`, `soft_delete`) VALUES
(1, 'PROGRAMMING LANGUAGE', 'PHP', 'PHP is a server scripting language, and a powerful tool for making dynamic and interactive Web pages.', 0),
(2, 'DATABASE', 'MYSQL', 'MySQL is the most popular Open Source Relational SQL Database Management System. ', 0),
(3, 'PROGRAMMING LANGUAGE', 'REACT', 'React is a JavaScript library for building user interfaces. It is maintained by Facebook and a community of individual developers and companies.', 0),
(4, 'PROGRAMMING LANGUAGE', 'JAVASCRIPT', 'JavaScript (JS) is a lightweight interpreted or just-in-time compiled programming language with first-class functions', 0),
(5, 'G & K', 'POLITICS', 'Politics refers to a set of activities associated with the governance of a country, or an area. It involves making decisions that apply to members of a group.', 0),
(6, 'ENGLISH', 'GRAMMAR', 'In linguistics, grammar is the set of structural rules governing the composition of clauses, phrases, and words in any given natural language.', 0),
(7, 'SOCIAL SCIENCE', 'HISTORY', 'History offers data on information of how people and societies lived and behaved in the past.History helps provide identity.', 0),
(8, 'SCIENCE', 'PHYSICS', 'Physics is one of the most fundamental scientific disciplines, and its main goal is to understand how the universe behaves.', 0);

-- --------------------------------------------------------

--
-- Table structure for table `Sample_users`
--

CREATE TABLE `Sample_users` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(15) NOT NULL,
  `type` enum('admin','user') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Sample_users`
--

INSERT INTO `Sample_users` (`id`, `username`, `password`, `type`) VALUES
(1, 'ravi', 'ravi', 'admin'),
(2, 'user', 'user', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Questions_set`
--
ALTER TABLE `Questions_set`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Quiz_categories`
--
ALTER TABLE `Quiz_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Quiz_topics`
--
ALTER TABLE `Quiz_topics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Sample_users`
--
ALTER TABLE `Sample_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Questions_set`
--
ALTER TABLE `Questions_set`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `Quiz_categories`
--
ALTER TABLE `Quiz_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `Quiz_topics`
--
ALTER TABLE `Quiz_topics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `Sample_users`
--
ALTER TABLE `Sample_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
