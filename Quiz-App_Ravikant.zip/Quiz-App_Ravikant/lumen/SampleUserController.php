<?php

namespace App\Http\Controllers;
use App\Model\SampleUserModel;
use Illuminate\http\Request;

class SampleUserController  
{  
    //This function is for Validating user.
    public function validateUser(Request $request)
    {
        if (!empty($request->input('username')) && !empty($request->input('password'))) {
            $username = $request->input('username');
            $password = $request->input('password');
            $_QuizObject=new SampleUserModel;
            return $_QuizObject->validateUser($username, $password);
        } else {
            return [];
        }
    }  
}