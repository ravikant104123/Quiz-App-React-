<?php

namespace App\Model;

use Jenssegers\Mongodb\Eloquent\Model as Eloquent;
use Illuminate\Support\Facades\DB;

use Illuminate\http\Request;

class SampleUserModel extends Eloquent
{
    //declaring constructor...for connection to proper database.
    public function __construct()
    {
        $this->MySQLConnection = DB::connection('mysql');
        $this->table_name = 'Sample_users';
    }

    //This function is for Validating user from Sample_users table.
    public function validateUser($username, $password)
    {
        $IncidentsQueryObj = $this->MySQLConnection
            ->table($this->table_name)
            ->where('username', $username)
            ->where('password', $password)->get();
        
        return $IncidentsQueryObj;
    }  
}
