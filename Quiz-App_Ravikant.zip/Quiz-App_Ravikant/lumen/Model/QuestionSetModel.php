<?php

namespace App\Model;

use Jenssegers\Mongodb\Eloquent\Model as Eloquent;
use Illuminate\Support\Facades\DB;

use Illuminate\http\Request;

class QuestionSetModel extends Eloquent
{
    //declaring constructor...for connection to proper database.
    public function __construct()
    {
        $this->MySQLConnection = DB::connection('mysql');
        $this->table_name4 = 'Questions_set';
    }

    //This function is for getting all the required questions from question_set table.
    public function getQuestion($id, $topic_name)
    {
        if (!empty($id)) {
            $IncidentsQueryObj = $this->MySQLConnection
                             ->table($this->table_name4)
                             ->where("id", $id)
                             ->get();
        } else if (!empty($topic_name)) {
            $IncidentsQueryObj = $this->MySQLConnection
                             ->table($this->table_name4)
                             ->where("topic_name", 'LIKE','%'.$topic_name.'%')
                             ->where("status", "Enabled")
                             ->get()->shuffle();

        } else {
            $IncidentsQueryObj = $this->MySQLConnection
                             ->table($this->table_name4)
                             ->where("status", "Enabled")
                             ->get();
        }
        
        
        return $IncidentsQueryObj;
    }

    //This function is for getting all the required questions from question_set table.
    public function postQuestion($data_array)
    {
        $IncidentsQueryObj = $this->MySQLConnection
                        ->table($this->table_name4)
                        ->insert([
                            'id' => $data_array['id'],
                            'topic_name' => strtoupper($data_array['topic_name']),
                            'question_title' => $data_array['question_title'],
                            'question_description' => $data_array['question_description'],
                            'options' => $data_array['options'],
                            'answer' => $data_array['answer'],
                            'status' => $data_array['status']
                        ]);
        return response()->json($IncidentsQueryObj);
    }

    //This function is for updating questions in question_set table.
    public function putQuestion($data_array)
    { 
        $IncidentsQueryObj = $this->MySQLConnection
                        ->table($this->table_name4)
                        ->where('id', $data_array['id'])
                        ->update( [
                            'topic_name' => strtoupper($data_array['topic_name']),
                            'question_title' => $data_array['question_title'],
                            'question_description' => $data_array['question_description'],
                            'options' => $data_array['options'],
                            'answer' => $data_array['answer'],
                            'status' => $data_array['status']
                        ]);
        return response()->json($IncidentsQueryObj);
    }

    //This function is for deleting questions in question_set table.
    public function deleteQuestion($id)
    {
        $IncidentsQueryObj = $this->MySQLConnection
                            ->table($this->table_name4)
                            ->where('id', $id)
                            ->update( [
                                'status' => "Disabled"
                                ]);  
        return  $IncidentsQueryObj;
    }
}
