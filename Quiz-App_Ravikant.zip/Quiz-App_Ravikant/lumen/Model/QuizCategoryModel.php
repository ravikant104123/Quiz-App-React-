<?php

namespace App\Model;

use Jenssegers\Mongodb\Eloquent\Model as Eloquent;
use Illuminate\Support\Facades\DB;

use Illuminate\http\Request;

class QuizCategoryModel extends Eloquent
{
    //declaring constructor...for connection to proper database.
    public function __construct()
    {
        $this->MySQLConnection = DB::connection('mysql');
        $this->table_name2 = 'Quiz_categories';
        $this->table_name3 = 'Quiz_topics';
    }

    //This function is for getting all the available quiz-categories.
    public function getCategories($id)
    {
        if (!empty($id)) {
            $IncidentsQueryObj = $this->MySQLConnection
            ->table($this->table_name2)
            ->where('id', (int)$id)
            ->where('soft_delete', 0)->get();
        } else {
            $IncidentsQueryObj = $this->MySQLConnection
            ->table($this->table_name2)
            ->where('soft_delete', 0)->get();
        }
        return $IncidentsQueryObj;
    }

    //This function is for inserting new category in quiz-categories table.
    public function postCategories($categories, $id)
    {
         //Checking whether categories with same name already exist or not?
        $Check = $this->MySQLConnection
            ->table($this->table_name2)
            ->select('id')
            ->where('categories', $categories)->get();

        if (count($Check)) {
            //this will only execute if categories alredy exist in Quiz_Category table. 

            //since categories is already existing so, updating it.
            $this->putCategories($categories, $Check[0]->id);
        } else {
            $IncidentsQueryObj = $this->MySQLConnection
                        ->table($this->table_name2)
                        ->insert([
                            'id' => $id,
                            'categories' => strtoupper($categories),
                            'soft_delete' => 0
            ]);
            return response()->json($IncidentsQueryObj);
        }
        
    }

    //This function is for updating category in quiz-categories table.
    public function putCategories($categories, $id)
    {
        $IncidentsQueryObj = $this->MySQLConnection
                    ->table($this->table_name2)
                    ->where('id', (int)$id)
                    ->update( [
                        'categories' => strtoupper($categories),
                        'soft_delete' => 0
                    ]);  

        //if this categories is also exist in Quiz_topic table then making it visible.
        $this->MySQLConnection->table($this->table_name3)
                            ->where('category_name', $categories)
                            ->update( [
                                    'soft_delete' => 0
                                ]);
        return  $IncidentsQueryObj;   
    }

    //This function is for deleting category in quiz-categories table.
    public function deleteCategories($id, $categories)
    {
        $IncidentsQueryObj = $this->MySQLConnection
                            ->table($this->table_name2)
                            ->where('id', $id)
                            ->update( [
                                'soft_delete' => 1
                                ]);

        //deleting categories from Quiz_topics if it has categories with the same name also.
        $this->MySQLConnection->table($this->table_name3)
                                ->where('category_name', $categories)
                                ->update( [
                                    'soft_delete' => 1
                                    ]);  
        return  $IncidentsQueryObj;  
    }    
}
