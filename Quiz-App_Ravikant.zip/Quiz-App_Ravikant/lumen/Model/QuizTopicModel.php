<?php

namespace App\Model;

use Jenssegers\Mongodb\Eloquent\Model as Eloquent;
use Illuminate\Support\Facades\DB;

use Illuminate\http\Request;

class QuizTopicModel extends Eloquent
{
    //declaring constructor...for connection to proper database.
    public function __construct()
    {
        $this->MySQLConnection = DB::connection('mysql');
        $this->table_name3 = 'Quiz_topics';
    }

    //This function is for getting all the available topics under specific quiz-categories.
    public function getTopics($id, $category_name, $topic_name)
    {
        $IncidentsQueryObj = $this->MySQLConnection
            ->table($this->table_name3)
            ->where('category_name', $category_name)
            ->orWhere('topic_name', $topic_name)
            ->orWhere('id', (int)$id)
            ->where('soft_delete', 0)
            ->get();
        
        return $IncidentsQueryObj;
    }

    //This function is for getting all the available topics in Quiz_topic tables.
    public function get_Topics()
    {
        $IncidentsQueryObj = $this->MySQLConnection
            ->table($this->table_name3)
            ->where('soft_delete', 0)
            ->get();
        
        return $IncidentsQueryObj;
    }

    //This function is for inserting topics under specific quiz-categories.
    public function postTopics($id, $topic_description, $topic_name, $category_name)
    {
        $Check = $this->MySQLConnection
            ->table($this->table_name3)
            ->select('id')
            ->where('topic_name', $topic_name)->get();

        if (count($Check)) {
            $this->putTopics($Check[0]->id, $topic_description, $topic_name, $category_name);
        } else {
            $IncidentsQueryObj = $this->MySQLConnection
                        ->table($this->table_name3)
                        ->insert([
                            'id' => $id,
                            'category_name' => strtoupper($category_name),
                            'topic_name' => strtoupper($topic_name),
                            'topic_description' => $topic_description,
                            'soft_delete' => 0
            ]);
            return response()->json($IncidentsQueryObj);
        }
    }

    //This function is for updating topic  under specific quiz-categories.
    public function putTopics($id, $topic_description, $topic_name, $category_name)
    {
        $IncidentsQueryObj = $this->MySQLConnection
                    ->table($this->table_name3)
                    ->where('id', (int)$id)
                    ->update( [
                        'category_name' => strtoupper($category_name),
                        'topic_name' => strtoupper($topic_name),
                        'topic_description' => $topic_description,
                        'soft_delete' => 0
                    ]);   
        return  $IncidentsQueryObj; 
    }

    //This function is for deleting topic  under specific quiz-categories.
    public function deleteTopics($id)
    {
        $IncidentsQueryObj = $this->MySQLConnection
                            ->table($this->table_name3)
                            ->where('id', $id)
                            ->update( [
                                'soft_delete' => 1
                                ]);  
        return  $IncidentsQueryObj; 
    }    
}
