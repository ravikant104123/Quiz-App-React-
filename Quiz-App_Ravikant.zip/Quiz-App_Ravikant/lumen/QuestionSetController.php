<?php

namespace App\Http\Controllers;
use App\Model\QuestionSetModel;
use Illuminate\http\Request;


class QuestionSetController  
{  
    //This function is for getting all the required questions from question_set table.
    public function getQuestion(Request $request)
    {
        $_QuizObject=new QuestionSetModel;
        return $_QuizObject->getQuestion((int)$request->input('id'), $request->input('topic_name'));
    }

    //This function is for getting all the required questions from question_set table.
    public function postQuestion(Request $request)
    {
        $_QuizObject=new QuestionSetModel;
        if (!empty($request->input('topic_name')) && !empty($request->input('question_title')) && !empty($request->input('question_description')) && !empty($request->input('options')) && !empty($request->input('answer')) && !empty($request->input('status'))) {
            $keys=array('id','topic_name','question_title','question_description','options','answer','status');
            $values = array((int)$request->input('id'),
                            $request->input('topic_name'),
                            $request->input('question_title'),
                            $request->input('question_description'),
                            $request->input('options'),
                            $request->input('answer'),
                            $request->input('status')
                        );
            $data_array = array_combine($keys, $values);
            return $_QuizObject->postQuestion($data_array);
        } else {
            return [];
        }
    }

    //This function is for updating questions in question_set table.
    public function putQuestion(Request $request)
    { 
        $_QuizObject=new QuestionSetModel;
        if (!empty($request->input('id')) && !empty($request->input('question_title')) && !empty($request->input('question_description')) && !empty($request->input('options')) && !empty($request->input('answer')) && !empty($request->input('status'))) {
            $keys=array('id','topic_name','question_title','question_description','options','answer','status');
            $values = array((int)$request->input('id'),
                            $request->input('topic_name'),
                            $request->input('question_title'),
                            $request->input('question_description'),
                            $request->input('options'),
                            $request->input('answer'),
                            $request->input('status')
                        );
            $data_array = array_combine($keys, $values);
            return $_QuizObject->putQuestion($data_array);
        } else {
            return 0;
        }
    }

    //This function is for deleting questions in question_set table.
    public function deleteQuestion(Request $request)
    {
        if (!empty($request->input('id'))) {
            $id = (int)$request->input('id');
            $_QuizObject=new QuestionSetModel;
            return $_QuizObject->deleteQuestion($id);
        } else {
            return [];
        }
    }
}
