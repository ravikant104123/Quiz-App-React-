<?php

namespace App\Http\Controllers;
use App\Model\QuizTopicModel;
use Illuminate\http\Request;

class QuizTopicController  
{  
    //This function is for getting all the available topics under specific quiz-categories.
    public function getTopics(Request $request)
    {
        $_QuizObject=new QuizTopicModel;
        if (!empty($request->input('category_name')) || !empty($request->input('topic_name')) || !empty($request->input('id'))) {
            $id = (int)$request->input('id');
            $category_name = $request->input('category_name');
            $topic_name = $request->input('topic_name');
            return $_QuizObject->getTopics($id, $category_name, $topic_name);
        } else {
            return $_QuizObject->get_Topics();
        }
    }


    //This function is for inserting topics under specific quiz-categories.
    public function postTopics(Request $request)
    {
        if (!empty($request->input('category_name')) && !empty($request->input('topic_name')) && !empty($request->input('topic_description'))) {
            $id = (int)$request->input('id');
            $topic_description = $request->input('topic_description');
            $topic_name = $request->input('topic_name');
            $category_name = $request->input('category_name');
            $_QuizObject=new QuizTopicModel;
            return $_QuizObject->postTopics($id, $topic_description, $topic_name, $category_name);
        } else {
            return [];
        }
    }

    //This function is for updating topic  under specific quiz-categories.
    public function putTopics(Request $request)
    { 
        if (!empty($request->input('category_name')) && !empty($request->input('topic_name')) && !empty($request->input('topic_description'))) {
            $id = (int)$request->input('id');
            $topic_description = $request->input('topic_description');
            $topic_name = $request->input('topic_name');
            $category_name = $request->input('category_name');
            $_QuizObject=new QuizTopicModel;
            return $_QuizObject->putTopics($id, $topic_description, $topic_name, $category_name);
        } else {
            return 0;
        }
    }

    //This function is for deleting topic  under specific quiz-categories.
    public function deleteTopics(Request $request)
    {
        if (!empty($request->input('id'))) {
            $id = (int)$request->input('id');
            $_QuizObject=new QuizTopicModel;
            return $_QuizObject->deleteTopics($id);
        } else {
            return 0;
        }
    }    
}
