<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$router->get('/', function () use ($router) {
    return $router->app->version();
});
/*---------------------------------------------------------------
                QUIZ APP
*/

//------for handling login ----------------------
$router->get('Quiz/login', 'SampleUserController@validateUser');
$router->post('Quiz/login', 'SampleUserController@insertNewUser');

//------for handling quiz categories--------------
$router->get('Quiz/categories', 'QuizCategoryController@getCategories');
$router->post('Quiz/categories', 'QuizCategoryController@postCategories');
$router->put('Quiz/categories', 'QuizCategoryController@putCategories');
$router->delete('Quiz/categories', 'QuizCategoryController@deleteCategories');

//------for handling quiz topics--------------
$router->get('Quiz/quiz_topics', 'QuizTopicController@getTopics');
$router->post('Quiz/quiz_topics', 'QuizTopicController@postTopics');
$router->put('Quiz/quiz_topics', 'QuizTopicController@putTopics');
$router->delete('Quiz/quiz_topics', 'QuizTopicController@deleteTopics');

//------for handling question set--------------
$router->get('Quiz/question_set', 'QuestionSetController@getQuestion');
$router->post('Quiz/question_set', 'QuestionSetController@postQuestion');
$router->put('Quiz/question_set', 'QuestionSetController@putQuestion');
$router->delete('Quiz/question_set', 'QuestionSetController@deleteQuestion');

