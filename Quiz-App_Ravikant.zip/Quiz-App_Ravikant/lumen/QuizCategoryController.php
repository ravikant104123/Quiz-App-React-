<?php

namespace App\Http\Controllers;
use App\Model\QuizCategoryModel;
use Illuminate\http\Request;

class QuizCategoryController  
{  
    //This function is for getting all the available quiz-categories.
    public function getCategories(Request $request)
    {
        $_QuizObject=new QuizCategoryModel;
        return $_QuizObject->getCategories($request->input('id'));
    }

    //This function is for inserting new category in quiz-categories table.
    public function postCategories(Request $request)
    {
        if (!empty($request->input('categories'))) {
            $id = (int)$request->input('id');
            $categories = $request->input('categories');
            $_QuizObject=new QuizCategoryModel;
            return $_QuizObject->postCategories($categories, $id);
        } else {
            return [];
        }
    }

    //This function is for updating category in quiz-categories table.
    public function putCategories(Request $request)
    {
        if (!empty($request->input('categories')) && !empty($request->input('id'))) {
            $categories = $request->input('categories');
            $id = (int)$request->input('id');
            $_QuizObject=new QuizCategoryModel;
            return $_QuizObject->putCategories($categories, $id);
        } else {
            return 0;
        }
    }

    //This function is for deleting category in quiz-categories table.
    public function deleteCategories(Request $request)
    {
        if (!empty($request->input('categories')) && !empty($request->input('id'))) {
            $id = (int)$request->input('id');
            $categories = $request->input('categories');
            $_QuizObject=new QuizCategoryModel;
            return $_QuizObject->deleteCategories($id, $categories);
        } else {
            return 0;
        }
    }    
}
